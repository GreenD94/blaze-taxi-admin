<?php if (isset($component)) { $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MasterLayout::class, ['assets' => $assets ?? []]); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <?php $id = $id ?? null;?>
        <?php if(isset($id)): ?>
            <?php echo Form::model($data, ['route' => ['service.update', $id], 'method' => 'patch' , 'enctype' => 'multipart/form-data']); ?>

        <?php else: ?>
            <?php echo Form::open(['route' => ['service.store'], 'method' => 'post', 'enctype' => 'multipart/form-data']); ?>

        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title"><?php echo e($pageTitle); ?></h4>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="new-user-info">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('name',__('message.name').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('name',old('name'),['placeholder' => __('message.name'),'class' =>'form-control','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php if( $id == null ): ?>
                                        <label class="form-control-label" for="region_id"><?php echo e(__('message.region')); ?> <span class="text-danger" id="distance_unit">* </span></label>
                                    <?php else: ?>
                                        <label class="form-control-label" for="region_id"><?php echo e(__('message.region')); ?> <span class="text-danger" id="distance_unit">* (<small><?php echo e(__('message.distance_in_'.optional($data->region)->distance_unit )); ?></small>)</span> </label>
                                    <?php endif; ?>
                                    <?php echo e(Form::select('region_id', isset($id) ? [ optional($data->region)->id => optional($data->region)->name ] : [] , old('region_id') , [
                                        'data-ajax--url' => route('ajax-list', [ 'type' => 'region' ]),
                                        'data-placeholder' => __('message.select_field', [ 'name' => __('message.region') ]),
                                        'class' =>'form-control select2js', 'required',
                                        'data-distance-unit' => isset($id) ? optional($data->region)->distance_unit : '',
                                        'id' => 'region_id'
                                        ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('capacity', __('message.capacity').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::number('capacity', old('capacity'),[ 'min' => 1, 'placeholder' => __('message.capacity'),'class' =>'form-control','required'])); ?>

                                </div>
                                
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('base_fare', __('message.base_fare').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::number('base_fare', old('base_fare'), ['class' => 'form-control', 'min' => 0, 'step' => 'any', 'required', 'placeholder' => __('message.base_fare') ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('minimum_fare', __('message.minimum_fare').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::number('minimum_fare', old('minimum_fare'), ['class' => 'form-control',  'min' => 0, 'step' => 'any', 'required', 'placeholder' => __('message.minimum_fare') ])); ?>

                                </div>
                                
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('minimum_distance',__('message.minimum_distance').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::number('minimum_distance', old('minimum_distance'),  ['class' => 'form-control', 'min' => 0, 'step' => 'any', 'placeholder' =>  __('message.minimum_distance') ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('per_distance',__('message.per_distance').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::number('per_distance', old('per_distance'),[ 'min' => 0, 'step' => 'any', 'placeholder' => __('message.per_distance'), 'class' => 'form-control' ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('per_minute_drive',__('message.per_minute_drive').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                    <?php echo e(Form::number('per_minute_drive', old('per_minute_drive'),[ 'min' => 0, 'step' => 'any', 'placeholder' => __('message.per_minute_drive'), 'class' => 'form-control' ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('waiting_time_limit',__('message.waiting_time_limit').'('.__('message.in_minutes').')<span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                    <?php echo e(Form::number('waiting_time_limit', old('waiting_time_limit'),[ 'min' => 0, 'step' => 'any', 'placeholder' => __('message.waiting_time_limit'), 'class' => 'form-control' ])); ?>

                                </div>
                                
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('per_minute_wait',__('message.per_minute_wait').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                    <?php echo e(Form::number('per_minute_wait', old('per_minute_wait'),[  'min' => 0, 'step' => 'any', 'placeholder' => __('message.per_minute_wait'), 'class' => 'form-control' ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('cancellation_fee', __('message.cancellation_fee').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::number('cancellation_fee', old('cancellation_fee'), ['class' => 'form-control',  'min' => 0, 'step' => 'any', 'required', 'placeholder' => __('message.cancellation_fee') ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('payment_method',__('message.payment_method').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                    <?php echo e(Form::select('payment_method',[ 'cash' => __('message.cash') ,'wallet' => __('message.wallet') , 'cash_wallet' => __('message.cash_wallet') ], old('payment_method') ,[ 'class' =>'form-control select2js','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('commission_type',__('message.commission_type'), ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::select('commission_type',[ 'fixed' => __('message.fixed') ,'percentage' => __('message.percentage') ], old('commission_type') ,[ 'class' =>'form-control select2js','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('admin_commission', __('message.admin_commission').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false)); ?>

                                    <?php echo e(Form::number('admin_commission', old('admin_commission'),[  'min' => 0, 'step' => 'any', 'placeholder' => __('message.admin_commission'), 'class' => 'form-control' ])); ?>

                                </div>

                            

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('status',__('message.status').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                    <?php echo e(Form::select('status',[ '1' => __('message.active'), '0' => __('message.inactive') ], old('status'), [ 'class' =>'form-control select2js','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <label class="form-control-label" for="image"><?php echo e(__('message.image')); ?> </label>
                                    <div class="custom-file">
                                        <input type="file" name="service_image" class="custom-file-input" accept="image/*">
                                        <label class="custom-file-label"><?php echo e(__('message.choose_file',['file' =>  __('message.image') ])); ?></label>
                                    </div>
                                    <span class="selected_file"></span>
                                </div>

                                <?php if( isset($id) && getMediaFileExit($data, 'service_image')): ?>
                                    <div class="col-md-2 mb-2">
                                        <img id="service_image_preview" src="<?php echo e(getSingleMedia($data,'service_image')); ?>" alt="service-image" class="attachment-image mt-1">
                                        <a class="text-danger remove-file" href="<?php echo e(route('remove.file', ['id' => $data->id, 'type' => 'service_image'])); ?>"
                                            data--submit='confirm_form'
                                            data--confirmation='true'
                                            data--ajax='true'
                                            data-toggle='tooltip'
                                            title='<?php echo e(__("message.remove_file_title" , ["name" =>  __("message.image") ])); ?>'
                                            data-title='<?php echo e(__("message.remove_file_title" , ["name" =>  __("message.image") ])); ?>'
                                            data-message='<?php echo e(__("message.remove_file_msg")); ?>'>
                                            <i class="ri-close-circle-line"></i>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('description',__('message.description'), ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::textarea('description', null, ['class'=>"form-control textarea" , 'rows'=>3  , 'placeholder'=> __('message.description') ])); ?>

                                </div>
                            </div>
                            <hr>
                            <?php echo e(Form::submit( __('message.save'), ['class'=>'btn btn-md btn-primary float-right'])); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
    <?php $__env->startSection('bottom_script'); ?>
    <script type="text/javascript">
        (function($) {
            "use strict";
            $(document).ready(function() {
                $(document).on('change', '#region_id' , function () {

                    var data = $(this).select2('data')[0];

                    var data_distance_unit = $('#region_id').attr('data-distance-unit',)
                    var distance_unit = data.distance_unit != undefined ? data.distance_unit : data_distance_unit;
                    
                    var text = "<?php echo e(__('message.distance_in_km')); ?>";
                    if ( distance_unit == 'mile' ) {
                        text = "<?php echo e(__('message.distance_in_mile')); ?>";
                    }
                    $('#distance_unit').html("* (<small>"+ text +"</small>)");
                });
            });
        })(jQuery);
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23)): ?>
<?php $component = $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23; ?>
<?php unset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23); ?>
<?php endif; ?>
<?php /**PATH C:\Users\juan_\Documents\Github\Bistro\blaze-taxi-admin\resources\views/service/form.blade.php ENDPATH**/ ?>